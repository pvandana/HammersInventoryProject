﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HammersInventoryProject.Models;

namespace HammersInventoryProject.Controllers
{
    public class HammersController : Controller
    {
        private HammerCompanyEntities db = new HammerCompanyEntities();

        // GET: Hammers
        public ActionResult Index()
        {
            var hammers = db.Hammers.Include(h => h.HammerType);
            return View(hammers.ToList());
        }

        // GET: Hammers/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Hammer hammer = db.Hammers.Find(id);
            if (hammer == null)
            {
                return HttpNotFound();
            }
            return View(hammer);
        }

        // GET: Hammers/Create
        public ActionResult Create()
        {
            ViewBag.HammerTypeId = new SelectList(db.HammerTypes, "Id", "Material");
            return View();
        }

        // POST: Hammers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,HammerTypeId,Length,Weight,Description")] Hammer hammer)
        {
            if (ModelState.IsValid)
            {
                db.Hammers.Add(hammer);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.HammerTypeId = new SelectList(db.HammerTypes, "Id", "Material", hammer.HammerTypeId);
            return View(hammer);
        }

        // GET: Hammers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Hammer hammer = db.Hammers.Find(id);
            if (hammer == null)
            {
                return HttpNotFound();
            }
            ViewBag.HammerTypeId = new SelectList(db.HammerTypes, "Id", "Material", hammer.HammerTypeId);
            return View(hammer);
        }

        // POST: Hammers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,HammerTypeId,Length,Weight,Description")] Hammer hammer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(hammer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.HammerTypeId = new SelectList(db.HammerTypes, "Id", "Material", hammer.HammerTypeId);
            return View(hammer);
        }

        // GET: Hammers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Hammer hammer = db.Hammers.Find(id);
            if (hammer == null)
            {
                return HttpNotFound();
            }
            return View(hammer);
        }

        // POST: Hammers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Hammer hammer = db.Hammers.Find(id);
            db.Hammers.Remove(hammer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
